package com.waelhamdi.carchecktn

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.app.*
import android.os.Build
import android.content.Context
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.Manifest
import android.content.pm.PackageManager
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import androidx.appcompat.app.AppCompatActivity

data class Item(val title:String, val text:String)

class MainActivity : AppCompatActivity() {
    private lateinit var content: LinearLayout
    private var obdSocket: BluetoothSocket? = null
    private var obdInput: InputStream? = null
    private var obdOutput: OutputStream? = null
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val obdExecutor = Executors.newSingleThreadExecutor()
    private val liveExecutor = Executors.newSingleThreadScheduledExecutor()
    private var liveTask: ScheduledFuture<*>? = null
    private var liveRunning = false
    private var lastDtcCodes: List<String> = emptyList()

    private val sections = listOf(
        "🔧 تشخيص ميكانيك" to listOf(
            Item("الكرهبة ترجّ", "الأسباب المحتملة: bougies/coil، injecteurs، admission، supports moteur، pneus أو transmission. إذا الرجّة قوية أو مع فقدان قوة، يلزم فحص سريع."),
            Item("الموتور يطلع حرارته", "راقب niveau liquide refroidissement، fuite، ventilateur، thermostat وpompe à eau. ما تفتحش bouchon متاع circuit وهو سخون."),
            Item("صوت طقطقة", "يلزم تحديد الصوت: من moteur، roue، suspension أو transmission. ما تبدل حتى قطعة قبل تحديد المصدر."),
            Item("الدوزيام/الفيتاس تضرب", "ممكن huile boîte ناقصة/قديمة، embrayage، tringlerie أو synchroniseur. جرّب هل المشكلة في سرعة معينة فقط."),
            Item("الكرهبة ما تطلعش مليح", "افحص air filter، fuel filter، bougies، injecteurs، throttle body، ضغط الوقود وcatalyseur حسب نوع المحرك."),
            Item("تستهلك essence برشا", "أسباب ممكنة: pneus ناقصين، filtre air، bougies، thermostat، injecteurs أو capteur O2/MAF/MAP. الاستهلاك يلزم يتحسب بالكيلومترات واللترات.")
        ),
        "⚡ كهرباء السيارة" to listOf(
            Item("البطارية تفرغ", "افحص عمر البطارية، أقطابها، تسريب كهربائي، وcharging voltage متاع alternateur. عادةً قياس الجهد يتم بالملتيمتر والمحرك خدام، حسب مواصفات السيارة."),
            Item("الضو ضعيف", "افحص البطارية، alternateur، masses، fusibles، sockets واللمبات."),
            Item("الديمارور ما يدورش", "افحص batterie، bornes، masse، fusible/relais وstarter. إذا تسمع click فقط، يلزم فحص أعمق."),
            Item("ضو moteur شاعل", "أفضل خطوة: OBD2 scan وقراءة DTC. الكود وحده موش بالضرورة القطعة المعطوبة؛ يلزم تفسيره مع الأعراض."),
            Item("Climatisation ما تبردش", "افحص الإعدادات، ventilateur، filtre habitacle، ضغط/تسريب refrigerant والcompresseur. خدمة الغاز يلزمها تجهيز مناسب.")
        ),
        "🛢️ الصيانة والسوائل" to listOf(
            Item("Vidange moteur", "تبديل زيت المحرك + filtre à huile حسب intervalle والمواصفات الموجودة في كتيب السيارة. ما تعتمدش على اللزوجة وحدها."),
            Item("Huile boîte", "نوع وكمية زيت boîte تختلف حسب السيارة. استعمل specification المصنع، موش أي زيت."),
            Item("Liquide refroidissement", "راقب المستوى والتسريب وحالة السائل. ما تخلطش أنواع مختلفة عشوائياً."),
            Item("Liquide frein", "راقب المستوى واللون وحالة النظام. إذا المستوى يهبط، يلزم البحث عن تسريب أو تآكل plaquettes."),
            Item("Filtre à air", "الفلتر الوسخ ينجم ينقص الأداء ويأثر على الاستهلاك. تغييره يكون حسب الحالة وintervalle الصيانة."),
            Item("Filtre essence/diesel", "تغييره حسب نوع النظام وجدول المصنع. مشاكل الفلتر تنجم تظهر كضعف أداء أو صعوبة تشغيل.")
        ),
        "⛽ الوقود والاستهلاك" to listOf(
            Item("Essence ولا Diesel؟", "التطبيق ينجم يحفظ نوع الوقود، وبعد يعطيك checklist خاص بالمحرك."),
            Item("حساب الاستهلاك", "أدخل اللترات والكيلومترات: الاستهلاك L/100km = اللترات ÷ الكيلومترات × 100."),
            Item("ريحة essence", "إذا ريحة وقود قوية، أوقف السيارة في مكان آمن وابعد عن النار والتدخين، وفتش على تسريب عند مختص."),
            Item("صعوبة التشغيل", "حسب المحرك: batterie/starter، fuel pressure، bougies أو glow plugs، sensors وimmobilizer.")
        ),
        "🚗 العجلات والفرامل والتعليق" to listOf(
            Item("رجة في volant", "ممكن équilibrage، pneu مشوه، jante، أو مشكلة في train avant. إذا الرجة تظهر مع سرعة معينة، يلزم فحص."),
            Item("الفرامل تصفر", "ممكن plaquettes مستهلكة أو غبرة/رطوبة، لكن يلزم فحص السماكة وحالة disque."),
            Item("السيارة تميل لجهة", "افحص ضغط العجلات، parallélisme، pneus، freins وsuspension."),
            Item("ضربة في المطبات", "افحص amortisseurs، silentblocs، rotules، biellettes وsupports.")
        ),
        "🔌 OBD2 وأكواد الأعطال" to listOf(
            Item("P0300", "Misfire عشوائي/متعدد الأسطوانات. الأسباب ممكنة من ignition، fuel أو air/compression. يلزم تشخيص السبب، موش تبديل bougies مباشرة."),
            Item("P0301–P0308", "Misfire في cylindre محدد. يلزم فحص bougie/coil/injecteur والcompression حسب الحالة."),
            Item("P0171", "الخليط Lean في بنك 1. ممكن vacuum leak، fuel pressure، MAF/MAP أو exhaust leak حسب السيارة."),
            Item("P0420", "كفاءة catalyseur أقل من المتوقع. الكود وحده ما يثبتش أن catalyseur هو السبب؛ يلزم فحص sensors والتسريبات."),
            Item("كيفاش نستعمل OBD2؟", "ركّب قارئ OBD2 في prise التشخيص، فعّل Bluetooth إذا القارئ يدعم ذلك، ثم اقرأ DTC. النسخة القادمة تنجم تربط القارئ مباشرة بالتطبيق.")
        ),
        "🔊 أصوات السيارة" to listOf(
            Item("صفير", "ممكن courroie، galet، alternateur أو فرامل حسب وقت ظهور الصوت."),
            Item("حكّة/احتكاك", "إذا من roue، الفرامل أو bearing محتملين. إذا الصوت قوي، ما تواصلش السياقة قبل الفحص."),
            Item("دقّ من moteur", "صوت طرق/دق قوي من المحرك يستحق إيقاف السيارة وفحصها، خاصة مع نقص الزيت أو ضوء الزيت."),
            Item("طنين مع السرعة", "ممكن pneus، roulement أو transmission. تحديد هل الصوت يتغير مع السرعة أو مع الدوران يساعد التشخيص.")
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        content = findViewById(R.id.content)
        showHome()
    }

    private fun tv(text:String, size:Float, color:Int=Color.WHITE, bold:Boolean=false):TextView =
        TextView(this).apply {
            this.text=text; textSize=size; setTextColor(color)
            setPadding(8,10,8,10); gravity=Gravity.CENTER
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }

    private fun button(text:String, action:()->Unit):Button =
        Button(this).apply {
            this.text=text; textSize=16f; setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(16,29,41)); setOnClickListener { action() }
            layoutParams=LinearLayout.LayoutParams(-1, 58).apply { setMargins(0,7,0,7) }
        }

    private fun showHome() {
        content.removeAllViews()
        content.addView(tv("CarCheck TN",30f,Color.WHITE,true))
        content.addView(tv("كاشف أعطال وصيانة السيارة بالتونسي",16f,Color.LTGRAY))
        content.addView(tv("اختار المجال اللي تحب تفحصو 👇",15f,Color.rgb(240,45,58),true))
        sections.forEach { (title, _) -> content.addView(button(title) { showSection(title) }) }
        content.addView(button("📋 Carnet d’entretien + الصيانة") { showMaintenance() })
        content.addView(button("⏰ تذكير بالـ Vidange") { showOilReminder() })
        content.addView(button("🔔 تنبيهات الصيانة") { showNotificationSettings() })
        content.addView(button("🔌 OBD2 Bluetooth") { showObd2() })
        content.addView(tv("© 2026 Wael Hamdi — جميع الحقوق محفوظة",13f,Color.LTGRAY))
        val ig=tv("Instagram: @wael.hamdyyy",14f,Color.rgb(240,45,58),true)
        ig.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/wael.hamdyyy/"))) }
        content.addView(ig)
    }

    private fun showSection(title:String) {
        content.removeAllViews()
        content.addView(button("← الرئيسية") { showHome() })
        content.addView(tv(title,25f,Color.WHITE,true))
        val data=sections.first { it.first==title }.second
        data.forEach { item ->
            val card=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL
                setPadding(14,12,14,12)
                setBackgroundColor(Color.rgb(16,29,41))
                layoutParams=LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,7,0,7) }
            }
            card.addView(tv(item.title,18f,Color.rgb(240,45,58),true))
            card.addView(tv(item.text,15f,Color.WHITE))
            content.addView(card)
        }
    }


    private fun hasBluetoothPermission(): Boolean {
        return Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    }

    private fun showObd2() {
        content.removeAllViews()
        content.addView(button("← الرئيسية") { stopLiveData(); disconnectObd(); showHome() })
        content.addView(tv("🔌 OBD2 Bluetooth — تشخيص متقدم",25f,Color.WHITE,true))
        content.addView(tv("اربط ELM327 Bluetooth بالسيارة، ركّب القارئ في prise OBD2 وخلي contact ON. بعض الوظائف تختلف حسب ECU.",15f,Color.LTGRAY))

        if (Build.VERSION.SDK_INT >= 31 && !hasBluetoothPermission()) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), 1001)
            content.addView(tv("اسمح بصلاحيات Bluetooth ثم ارجع للصفحة.",14f,Color.YELLOW,true))
            return
        }

        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            content.addView(tv("❌ التلفون ما يدعمش Bluetooth.",16f,Color.RED,true)); return
        }
        if (!adapter.isEnabled) {
            content.addView(button("📡 شغّل Bluetooth") { startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) })
        }

        content.addView(tv("اختار ELM327 من الأجهزة المقترنة:",15f,Color.WHITE,true))
        val paired = try { adapter.bondedDevices.toList() } catch (_: SecurityException) { emptyList() }
        if (paired.isEmpty()) {
            content.addView(tv("ما فماش أجهزة مقترنة. اعمل Pair من إعدادات Bluetooth أولاً.",14f,Color.LTGRAY))
        } else {
            paired.forEach { device ->
                content.addView(button("${device.name ?: "جهاز Bluetooth"}\n${device.address}") { connectObd(device) })
            }
        }

        content.addView(button("🔴 قطع الاتصال") { stopLiveData(); disconnectObd(); Toast.makeText(this,"تم قطع OBD2",Toast.LENGTH_SHORT).show() })
        content.addView(button("📟 Live Data الآن") { readLiveData() })
        content.addView(button("🔄 Live Data تلقائي كل ثانية") { toggleLiveData() })
        content.addView(button("⚠️ قراءة أكواد الأعطال DTC") { readDtc() })
        content.addView(button("🧹 مسح أكواد الأعطال") { clearDtc() })
        content.addView(button("🚗 معلومات السيارة / VIN") { readVehicleInfo() })
        content.addView(button("🩺 حالة نظام التشخيص") { readMonitorStatus() })
        content.addView(tv("Live PIDs: RPM • سرعة • حرارة الماء • حرارة الهواء • MAF • Throttle • حمل المحرك • ضغط الوقود • مستوى الوقود (إذا مدعوم).\n\n⚠️ مسح DTC يطفي لمبة Check Engine أحياناً، لكن إذا العطل ما تصلحش الكود يرجع. ما تمسحش الأكواد قبل ما تحفظها.",13f,Color.LTGRAY))
    }

    private fun connectObd(device: BluetoothDevice) {
        if (!hasBluetoothPermission()) {
            Toast.makeText(this,"اسمح بصلاحية Bluetooth أولاً",Toast.LENGTH_SHORT).show(); return
        }
        Thread {
            try {
                obdSocket?.close()
                val socket = device.createRfcommSocketToServiceRecord(sppUuid)
                socket.connect()
                obdSocket = socket
                obdInput = socket.inputStream
                obdOutput = socket.outputStream
                sendObd("ATZ")
                sendObd("ATE0")
                sendObd("ATL0")
                sendObd("ATS0")
                sendObd("ATH0")
                sendObd("ATSP0")
                runOnUiThread { Toast.makeText(this,"✅ OBD2 متصل: ${device.name ?: "ELM327"}",Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this,"❌ فشل الاتصال OBD2: ${e.message}",Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun sendObd(command: String): String {
        val out = obdOutput ?: return "غير متصل"
        val input = obdInput ?: return "غير متصل"
        out.write((command + "\r").toByteArray())
        out.flush()
        val end = System.currentTimeMillis() + 2500
        val sb = StringBuilder()
        val buffer = ByteArray(256)
        while (System.currentTimeMillis() < end) {
            try {
                if (input.available() > 0) {
                    val n = input.read(buffer)
                    if (n > 0) {
                        sb.append(String(buffer,0,n))
                        if (sb.contains(">")) break
                    }
                } else Thread.sleep(40)
            } catch (_: Exception) { break }
        }
        return sb.toString().replace("\r", " ").replace("\n", " ").trim()
    }

    private fun isObdConnected(): Boolean = obdSocket?.isConnected == true && obdInput != null && obdOutput != null

    private fun readLiveSnapshot(): String {
        if (!isObdConnected()) return "❌ OBD2 موش متصل. اختار ELM327 أولاً."
        val rpm = parsePid010C(sendObd("010C"))
        val speed = parsePid010D(sendObd("010D"))
        val coolant = parsePid0105(sendObd("0105"))
        val intake = parsePid010F(sendObd("010F"))
        val maf = parsePid0110(sendObd("0110"))
        val throttle = parsePid0111(sendObd("0111"))
        val load = parsePid0104(sendObd("0104"))
        val fuelPressure = parsePid010A(sendObd("010A"))
        val fuelLevel = parsePid012F(sendObd("012F"))
        return "📊 Live Data\n" +
                "RPM: ${rpm ?: "N/A"}\n" +
                "السرعة: ${speed?.let { "$it km/h" } ?: "N/A"}\n" +
                "حرارة المحرك: ${coolant?.let { "$it °C" } ?: "N/A"}\n" +
                "حرارة الهواء: ${intake?.let { "$it °C" } ?: "N/A"}\n" +
                "MAF: ${maf?.let { "%.1f g/s".format(it) } ?: "N/A"}\n" +
                "Throttle: ${throttle?.let { "$it %" } ?: "N/A"}\n" +
                "حمل المحرك: ${load?.let { "$it %" } ?: "N/A"}\n" +
                "ضغط الوقود: ${fuelPressure?.let { "$it kPa" } ?: "N/A"}\n" +
                "مستوى الوقود: ${fuelLevel?.let { "$it %" } ?: "N/A"}"
    }

    private fun readLiveData() {
        obdExecutor.execute {
            val result = readLiveSnapshot()
            runOnUiThread { showObdResult(result) }
        }
    }

    private fun toggleLiveData() {
        if (liveRunning) {
            stopLiveData()
            Toast.makeText(this,"تم إيقاف Live Data",Toast.LENGTH_SHORT).show()
        } else {
            if (!isObdConnected()) { Toast.makeText(this,"اربط OBD2 أولاً",Toast.LENGTH_SHORT).show(); return }
            liveRunning = true
            liveTask = liveExecutor.scheduleAtFixedRate({
                val result = readLiveSnapshot()
                runOnUiThread { showObdResult(result) }
            }, 0, 1, TimeUnit.SECONDS)
            Toast.makeText(this,"Live Data خدامة 🔄",Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopLiveData() {
        liveTask?.cancel(true)
        liveTask = null
        liveRunning = false
    }

    private fun readDtc() {
        obdExecutor.execute {
            val raw = sendObd("03")
            val codes = parseDtc(raw)
            lastDtcCodes = codes
            val explanation = if (codes.isEmpty()) "ما لقيتش كود واضح في الرد." else codes.joinToString("\n") { "$it — ${dtcExplanation(it)}" }
            runOnUiThread { showObdResult("⚠️ أكواد الأعطال DTC\n$explanation\n\nRaw: $raw") }
        }
    }

    private fun clearDtc() {
        if (!isObdConnected()) { Toast.makeText(this,"اربط OBD2 أولاً",Toast.LENGTH_SHORT).show(); return }
        new AlertDialog.Builder(this)
            .setTitle("🧹 مسح أكواد الأعطال؟")
            .setMessage("هذا الأمر يطلب من ECU مسح DTC وبيانات مرتبطة بها، وقد يطفي Check Engine مؤقتاً. سجّل الأكواد واعالج السبب قبل المسح.")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("مسح") { _, _ ->
                obdExecutor.execute {
                    val raw = sendObd("04")
                    runOnUiThread { showObdResult("🧹 نتيجة مسح DTC\n$raw") }
                }
            }.show()
    }

    private fun readVehicleInfo() {
        obdExecutor.execute {
            val raw = sendObd("0902")
            val vin = parseVin(raw)
            runOnUiThread { showObdResult("🚗 VIN / معلومات السيارة\n${vin ?: "VIN غير مدعوم أو الرد غير واضح."}\n\nRaw: $raw") }
        }
    }

    private fun readMonitorStatus() {
        obdExecutor.execute {
            val raw = sendObd("0101")
            runOnUiThread { showObdResult("🩺 حالة نظام التشخيص\n${parseMonitor(raw)}\n\nRaw: $raw") }
        }
    }

    private fun showObdResult(text:String) {
        val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(14,12,14,12); setBackgroundColor(Color.rgb(16,29,41)); layoutParams=LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,10,0,10) } }
        card.addView(tv(text,15f,Color.WHITE))
        content.addView(card)
    }

    private fun hexBytes(raw:String): List<Int> = raw.uppercase().split(Regex("[^0-9A-F]+" )).filter { it.length==2 }.mapNotNull { it.toIntOrNull(16) }
    private fun pidBytes(raw:String, pid:Int): List<Int> {
        val b=hexBytes(raw)
        for (x in 0 until b.size-1) if (b[x]==0x41 && b[x+1]==pid) return b.drop(x+2)
        return emptyList()
    }
    private fun parsePid010C(raw:String): Int? { val b=pidBytes(raw,0x0C); return if(b.size>=2) ((b[0]*256+b[1])/4) else null }
    private fun parsePid010D(raw:String): Int? { val b=pidBytes(raw,0x0D); return b.firstOrNull() }
    private fun parsePid0105(raw:String): Int? { val b=pidBytes(raw,0x05); return b.firstOrNull()?.minus(40) }
    private fun parsePid010F(raw:String): Int? { val b=pidBytes(raw,0x0F); return b.firstOrNull()?.minus(40) }
    private fun parsePid0110(raw:String): Double? { val b=pidBytes(raw,0x10); return if(b.size>=2) (b[0]*256+b[1])/100.0 else null }
    private fun parsePid0111(raw:String): Int? { val b=pidBytes(raw,0x11); return b.firstOrNull()?.let { it*100/255 } }
    private fun parsePid0104(raw:String): Int? { val b=pidBytes(raw,0x04); return b.firstOrNull()?.let { it*100/255 } }
    private fun parsePid010A(raw:String): Int? { val b=pidBytes(raw,0x0A); return b.firstOrNull()?.let { it*3 } }
    private fun parsePid012F(raw:String): Int? { val b=pidBytes(raw,0x2F); return b.firstOrNull()?.let { it*100/255 } }

    private fun parseDtc(raw:String): List<String> {
        val b=hexBytes(raw); val i=b.indexOfFirst { it==0x43 }; if(i<0) return emptyList(); val out=mutableListOf<String>(); var p=i+1
        while(p+1<b.size) { val a=b[p]; val c=b[p+1]; if(a==0 && c==0) break; val prefix=when((a shr 6) and 3){0->"P";1->"C";2->"B";else->"U"}; val d1=((a shr 4) and 3).toString(); val chars="0123456789ABCDEF"; out.add(prefix+d1+chars[a and 15]+chars[c shr 4]+chars[c and 15]); p+=2 }
        return out
    }

    private fun dtcExplanation(code:String): String = when(code) {
        "P0300" -> "Misfire عشوائي/متعدد — ignition أو fuel أو compression"
        in "P0301".."P0308" -> "Misfire في cylindre محدد — افحص bougie/coil/injecteur/compression"
        "P0171" -> "الخليط Lean — vacuum leak أو fuel pressure أو MAF/MAP حسب السيارة"
        "P0172" -> "الخليط Rich — fuel/air sensor أو injecteur أو ضغط وقود"
        "P0420" -> "كفاءة catalyseur منخفضة — افحص التسريبات وO2 قبل تبديل catalyseur"
        "P0401" -> "تدفق EGR غير كافٍ"
        "P0101" -> "إشارة MAF خارج النطاق المتوقع"
        "P0113" -> "إشارة حساس حرارة هواء السحب مرتفعة"
        "P0128" -> "حرارة المحرك أقل من المتوقع — thermostat/coolant محتمل"
        "P0500" -> "خلل في إشارة سرعة السيارة"
        else -> "كود يحتاج تفسير حسب الموديل والمحرك"
    }

    private fun parseVin(raw:String): String? {
        val b=hexBytes(raw); val chars=StringBuilder()
        var i=0
        while(i<b.size) {
            if(b[i]==0x49 && i+2<b.size && b[i+1]==0x02) { i+=3; continue }
            val v=b[i]
            if(v in 0x20..0x7E) chars.append(v.toChar())
            i++
        }
        val candidate=chars.toString().replace("\u0000","").trim()
        return candidate.takeIf { it.length >= 11 && it.any(Char::isLetterOrDigit) }
    }

    private fun parseMonitor(raw:String): String {
        val b=pidBytes(raw,0x01)
        if(b.size<4) return "الـECU ما رجعش بيانات Monitor واضحة."
        val mil=b[0] and 0x80 != 0
        val dtcCount=b[0] and 0x7F
        return "DTC المسجلة: $dtcCount\nCheck Engine MIL: ${if(mil) "شاعلة" else "مطفية"}\nبيانات readiness متاحة من الـECU."
    }

    private fun disconnectObd() { stopLiveData(); try { obdSocket?.close() } catch (_: Exception) {}; obdSocket=null; obdInput=null; obdOutput=null }

    override fun onDestroy() { stopLiveData(); obdExecutor.shutdownNow(); liveExecutor.shutdownNow(); disconnectObd(); super.onDestroy() }

    private fun showOilReminder() {
        content.removeAllViews()
        content.addView(button("← الرئيسية") { showHome() })
        content.addView(tv("⏰ تذكير بالـ Vidange",25f,Color.WHITE,true))
        content.addView(tv("حطّ تاريخ آخر Vidange أو الكيلومترات، والتطبيق ينبهك كي يقرب الموعد.",15f,Color.LTGRAY))

        val date = EditText(this).apply {
            hint = "تاريخ آخر Vidange (مثال: 15/09/2026)"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            inputType = android.text.InputType.TYPE_CLASS_DATETIME
        }
        content.addView(date)

        val km = EditText(this).apply {
            hint = "Kilométrage وقت الـ Vidange"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        content.addView(km)

        val interval = EditText(this).apply {
            hint = "Interval بالكيلومترات (مثال: 10000)"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText("10000")
        }
        content.addView(interval)

        content.addView(button("🔔 فعّل التذكير") {
            val prefs = getSharedPreferences("carcheck", Context.MODE_PRIVATE)
            prefs.edit()
                .putString("oil_date", date.text.toString())
                .putInt("oil_km", km.text.toString().toIntOrNull() ?: 0)
                .putInt("oil_interval", interval.text.toString().toIntOrNull() ?: 10000)
                .putBoolean("oil_reminder", true)
                .apply()
            Toast.makeText(this, "تم تفعيل تذكير الـ Vidange 🔔", Toast.LENGTH_LONG).show()
            scheduleOilReminder()
        })

        val prefs = getSharedPreferences("carcheck", Context.MODE_PRIVATE)
        if (prefs.getBoolean("oil_reminder", false)) {
            val lastKm = prefs.getInt("oil_km", 0)
            val intKm = prefs.getInt("oil_interval", 10000)
            content.addView(tv("آخر Vidange: ${prefs.getString("oil_date","غير محدد")}\nKilométrage: $lastKm km\nالتذكير مضبوط كل $intKm km",14f,Color.rgb(66,211,146),true))
        }
    }

    private fun scheduleOilReminder() {
        val prefs = getSharedPreferences("carcheck_service", Context.MODE_PRIVATE)
        val tasks = listOf(
            "🛢️ Vidange + filtre huile" to 10000,
            "🌬️ Filtre à air" to 15000,
            "💨 Filtre habitacle" to 15000,
            "⛽ Filtre essence/diesel" to 30000,
            "🛑 Plaquettes de frein" to 20000,
            "🛞 Pneus" to 40000,
            "🔋 Batterie" to 40000,
            "💧 Liquide frein" to 30000,
            "🌡️ Liquide refroidissement" to 40000,
            "⚙️ Courroie distribution" to 60000,
            "🔧 Bougies" to 30000,
            "⚡ Contrôle alternateur" to 20000
        )
        createNotificationChannel()

        val currentKm = prefs.getInt("current_km", 0)
        tasks.forEachIndexed { index, (name, _) ->
            val last = prefs.getInt(name + "_km", 0)
            val interval = prefs.getInt(name + "_interval", 0)
            if (last > 0 && interval > 0 && currentKm >= last + interval - 500) {
                showMaintenanceNotification(
                    index + 1,
                    "صيانة قريبة 🚗",
                    "$name: باقي تقريبًا ${maxOf(0, last + interval - currentKm)} km."
                )
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(
                    "maintenance",
                    "تنبيهات صيانة السيارة",
                    NotificationManager.IMPORTANCE_DEFAULT
                )
            )
        }
    }

    private fun showMaintenanceNotification(id:Int, title:String, body:String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") !=
            android.content.pm.PackageManager.PERMISSION_GRANTED) return

        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = Notification.Builder(this, "maintenance")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .build()
        manager.notify(id, notification)
    }

    private fun showNotificationSettings() {
        content.removeAllViews()
        content.addView(button("← الرئيسية") { showHome() })
        content.addView(tv("🔔 تنبيهات الصيانة",25f,Color.WHITE,true))
        content.addView(tv(
            "التطبيق ينجم ينبهك كي تقرب صيانة حسب الـKilométrage اللي سجلتو. في النسخة الحالية، لازم تحدّث Kilométrage الحالي يدويًا.",
            15f, Color.LTGRAY
        ))

        val current = getSharedPreferences("carcheck_service", Context.MODE_PRIVATE)
            .getInt("current_km", 0)

        val input = EditText(this).apply {
            hint = "Kilométrage الحالي"
            setText(if (current > 0) current.toString() else "")
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        content.addView(input)

        content.addView(button("💾 تحديث Kilométrage + فحص التنبيهات") {
            val km = input.text.toString().toIntOrNull()
            if (km == null || km < 0) {
                Toast.makeText(this, "دخل Kilométrage صحيح.", Toast.LENGTH_SHORT).show()
            } else {
                getSharedPreferences("carcheck_service", Context.MODE_PRIVATE)
                    .edit().putInt("current_km", km).apply()
                scheduleOilReminder()
                Toast.makeText(this, "تحدّث الـKilométrage وتم فحص الصيانة 🔔", Toast.LENGTH_LONG).show()
            }
        })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 100)
        }
    }


    private fun showMaintenance() {
        content.removeAllViews()
        content.addView(button("← الرئيسية") { showHome() })
        content.addView(tv("📋 Carnet d'entretien",25f,Color.WHITE,true))
        content.addView(tv("سجّل آخر مرة عملت فيها كل صيانة، والتطبيق يحسبلك الموعد الجاي.",15f,Color.LTGRAY))

        val tasks = listOf(
            "🛢️ Vidange + filtre huile" to 10000,
            "🌬️ Filtre à air" to 15000,
            "💨 Filtre habitacle" to 15000,
            "⛽ Filtre essence/diesel" to 30000,
            "🛑 Plaquettes de frein" to 20000,
            "🛞 Pneus" to 40000,
            "🔋 Batterie" to 40000,
            "💧 Liquide frein" to 30000,
            "🌡️ Liquide refroidissement" to 40000,
            "⚙️ Courroie distribution" to 60000,
            "🔧 Bougies" to 30000,
            "⚡ Contrôle alternateur" to 20000
        )

        val prefs = getSharedPreferences("carcheck_service", Context.MODE_PRIVATE)

        tasks.forEach { (name, defaultInterval) ->
            val savedKm = prefs.getInt(name + "_km", 0)
            val savedInterval = prefs.getInt(name + "_interval", defaultInterval)

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 10, 14, 10)
                setBackgroundColor(Color.rgb(16,29,41))
                layoutParams = LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,7,0,7) }
            }

            card.addView(tv(name,17f,Color.WHITE,true))
            card.addView(tv(
                if (savedKm > 0)
                    "آخر مرة: $savedKm km • Interval: $savedInterval km\nالموعد التقريبي: ${savedKm + savedInterval} km"
                else
                    "مازال ما تسجلتش الصيانة.",
                14f, Color.LTGRAY
            ))

            val kmInput = EditText(this).apply {
                hint = "Kilométrage وقت الصيانة"
                setTextColor(Color.WHITE)
                setHintTextColor(Color.LTGRAY)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
            }
            card.addView(kmInput)

            val intervalInput = EditText(this).apply {
                hint = "Interval km"
                setTextColor(Color.WHITE)
                setHintTextColor(Color.LTGRAY)
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                setText(savedInterval.toString())
            }
            card.addView(intervalInput)

            val save = Button(this).apply {
                text = "💾 حفظ"
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.rgb(240,45,58))
                setOnClickListener {
                    val k = kmInput.text.toString().toIntOrNull()
                    val i = intervalInput.text.toString().toIntOrNull()
                    if (k == null || i == null || k < 0 || i <= 0) {
                        Toast.makeText(this@MainActivity, "دخل Kilométrage و Interval صحيحين.", Toast.LENGTH_SHORT).show()
                    } else {
                        prefs.edit().putInt(name + "_km", k).putInt(name + "_interval", i).apply()
                        scheduleOilReminder()
                        Toast.makeText(this@MainActivity, "تسجّلت: $name 🔔", Toast.LENGTH_SHORT).show()
                        showMaintenance()
                    }
                }
            }
            card.addView(save)
            content.addView(card)
        }

        content.addView(tv(
            "⚠️ ملاحظة: المواعيد الافتراضية تقريبية. ديما اتبع كتيب السيارة والمواصفات متاع الموديل والموتور. القطع اللي عندها علاقة بالفرامل، التوجيه، التوزيع أو الوقود يلزم فحص مختص.",
            14f, Color.rgb(255,190,80), true
        ))
    }
}
