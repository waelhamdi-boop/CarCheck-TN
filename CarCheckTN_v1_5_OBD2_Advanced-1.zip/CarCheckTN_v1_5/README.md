# CarCheck TN v1.5 — OBD2 Advanced

Android project (Kotlin/XML) for CarCheck TN.

## OBD2 Bluetooth
- ELM327 Classic Bluetooth SPP connection
- ELM327 initialization (ATZ/ATE0/ATL0/ATS0/ATH0/ATSP0)
- Live Data: RPM, speed, coolant temperature, intake temperature, MAF, throttle, engine load, fuel pressure and fuel level when supported
- One-shot and automatic Live Data refresh every second
- DTC reading and basic Tunisian-Arabic explanations
- DTC clear command (Mode 04) with confirmation warning
- VIN request (Mode 09 PID 02) when supported
- Diagnostic monitor / MIL / DTC count (Mode 01 PID 01)

## Existing features
- Tunisian Arabic mechanical/electrical diagnostic library
- Maintenance carnet and intervals
- Oil-change reminder
- Maintenance notifications
- Fuel, fluids, brakes, suspension, tires and sound checklists
- Wael Hamdi ownership/copyright and Instagram reference

## Important
OBD-II support varies by vehicle, ECU and adapter. ELM327 clones may not support every command. Never clear a fault code before recording it and investigating the cause. The app is a diagnostic aid, not a replacement for a qualified mechanic.

Build with Android Studio or a compatible Android IDE.
